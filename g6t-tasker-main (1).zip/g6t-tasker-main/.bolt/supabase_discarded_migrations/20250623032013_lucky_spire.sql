/*
  # Fix task status enum to match application requirements

  1. Changes
    - Add missing status values to task_status enum: 'sin_asignar', 'en_proceso', 'aplazada', 'archivada'
    - Update existing tasks that use old status values
    - Set default status for new tasks

  2. Security
    - No changes to RLS policies needed
*/

-- Step 1: Add the new enum values (without using them yet)
DO $$
BEGIN
    -- Add 'sin_asignar' if it doesn't exist
    IF NOT EXISTS (SELECT 1 FROM pg_enum WHERE enumlabel = 'sin_asignar' AND enumtypid = (SELECT oid FROM pg_type WHERE typname = 'task_status')) THEN
        ALTER TYPE task_status ADD VALUE 'sin_asignar';
    END IF;
    
    -- Add 'en_proceso' if it doesn't exist
    IF NOT EXISTS (SELECT 1 FROM pg_enum WHERE enumlabel = 'en_proceso' AND enumtypid = (SELECT oid FROM pg_type WHERE typname = 'task_status')) THEN
        ALTER TYPE task_status ADD VALUE 'en_proceso';
    END IF;
    
    -- Add 'aplazada' if it doesn't exist
    IF NOT EXISTS (SELECT 1 FROM pg_enum WHERE enumlabel = 'aplazada' AND enumtypid = (SELECT oid FROM pg_type WHERE typname = 'task_status')) THEN
        ALTER TYPE task_status ADD VALUE 'aplazada';
    END IF;
    
    -- Add 'archivada' if it doesn't exist
    IF NOT EXISTS (SELECT 1 FROM pg_enum WHERE enumlabel = 'archivada' AND enumtypid = (SELECT oid FROM pg_type WHERE typname = 'task_status')) THEN
        ALTER TYPE task_status ADD VALUE 'archivada';
    END IF;
END $$;

-- Step 2: Commit the enum changes by ending this transaction
COMMIT;

-- Step 3: Start a new transaction to use the new enum values
BEGIN;

-- Update any existing tasks that might have 'en_progreso' to use 'en_proceso'
-- This will only work if there are tasks with 'en_progreso' status
DO $$
BEGIN
    -- Check if 'en_progreso' exists in the enum and update if needed
    IF EXISTS (SELECT 1 FROM pg_enum WHERE enumlabel = 'en_progreso' AND enumtypid = (SELECT oid FROM pg_type WHERE typname = 'task_status')) THEN
        UPDATE tasks SET status = 'en_proceso' WHERE status = 'en_progreso';
    END IF;
END $$;

-- Set default status for new tasks to 'sin_asignar'
ALTER TABLE tasks ALTER COLUMN status SET DEFAULT 'sin_asignar';

-- Update existing unassigned tasks to have the correct status
UPDATE tasks 
SET status = 'sin_asignar'
WHERE id NOT IN (
  SELECT DISTINCT task_id FROM task_assignments
) AND status = 'pendiente';

-- Update the get_task_statuses function to return all available statuses
CREATE OR REPLACE FUNCTION get_task_statuses()
RETURNS TABLE (value text, label text)
LANGUAGE sql
SECURITY DEFINER
AS $$
  SELECT 
    unnest(ARRAY[
      'sin_asignar', 
      'pendiente', 
      'en_proceso', 
      'aplazada', 
      'cancelada', 
      'completada', 
      'archivada'
    ]) as value,
    unnest(ARRAY[
      'Sin Asignar', 
      'Pendiente', 
      'En Proceso', 
      'Aplazada', 
      'Cancelada', 
      'Completada', 
      'Archivada'
    ]) as label;
$$;

COMMIT;