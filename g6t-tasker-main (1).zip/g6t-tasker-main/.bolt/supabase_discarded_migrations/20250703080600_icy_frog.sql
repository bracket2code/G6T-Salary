/*
  # Fix task history to show correct user names

  1. Changes
    - Update the task history system to properly show user names
    - Fix the trigger functions to correctly capture user information
    - Ensure history entries show the actual user name instead of "Sistema"

  2. Security
    - Maintain existing RLS policies
    - No changes to permissions needed
*/

-- Update the get_task_history function to properly join with workers table
CREATE OR REPLACE FUNCTION get_task_history(p_task_id uuid)
RETURNS TABLE (
  id uuid,
  action_type task_action_type,
  old_value text,
  new_value text,
  description text,
  created_at timestamptz,
  user_name text,
  user_role worker_role
)
LANGUAGE sql
AS $$
  SELECT 
    th.id,
    th.action_type,
    th.old_value,
    th.new_value,
    th.description,
    th.created_at,
    w.name as user_name,
    w.role as user_role
  FROM task_history th
  LEFT JOIN workers w ON th.user_id = w.id
  WHERE th.task_id = p_task_id
  ORDER BY th.created_at DESC;
$$;

-- Update the trigger function for task changes to properly capture user info
CREATE OR REPLACE FUNCTION trigger_log_task_changes()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  current_user_id uuid;
  current_user_name text;
BEGIN
  -- Get the current user ID
  current_user_id := auth.uid();
  
  -- Get the current user name
  SELECT name INTO current_user_name FROM workers WHERE id = current_user_id;
  
  IF TG_OP = 'INSERT' THEN
    -- Log task creation with the real user name
    INSERT INTO task_history (
      task_id,
      user_id,
      action_type,
      old_value,
      new_value,
      description,
      created_at
    ) VALUES (
      NEW.id,
      current_user_id,
      'created'::task_action_type,
      NULL,
      NEW.title,
      'Tarea creada por ' || COALESCE(current_user_name, 'Usuario') || ': "' || NEW.title || '"',
      NEW.created_at
    );
    RETURN NEW;
  ELSIF TG_OP = 'UPDATE' THEN
    -- Log status change with user name
    IF OLD.status != NEW.status THEN
      INSERT INTO task_history (
        task_id,
        user_id,
        action_type,
        old_value,
        new_value,
        description,
        created_at
      ) VALUES (
        NEW.id,
        current_user_id,
        'status_change'::task_action_type,
        OLD.status::text,
        NEW.status::text,
        'Estado cambiado por ' || COALESCE(current_user_name, 'Usuario') || ' de "' || OLD.status::text || '" a "' || NEW.status::text || '"',
        now()
      );
    END IF;
    
    -- Log priority change with user name
    IF OLD.priority != NEW.priority THEN
      INSERT INTO task_history (
        task_id,
        user_id,
        action_type,
        old_value,
        new_value,
        description,
        created_at
      ) VALUES (
        NEW.id,
        current_user_id,
        'priority_change'::task_action_type,
        OLD.priority::text,
        NEW.priority::text,
        'Prioridad cambiada por ' || COALESCE(current_user_name, 'Usuario') || ' de "' || OLD.priority::text || '" a "' || NEW.priority::text || '"',
        now()
      );
    END IF;
    
    -- Log description change with user name
    IF COALESCE(OLD.description, '') != COALESCE(NEW.description, '') THEN
      INSERT INTO task_history (
        task_id,
        user_id,
        action_type,
        old_value,
        new_value,
        description,
        created_at
      ) VALUES (
        NEW.id,
        current_user_id,
        'description_change'::task_action_type,
        LEFT(OLD.description, 50),
        LEFT(NEW.description, 50),
        'Descripción actualizada por ' || COALESCE(current_user_name, 'Usuario'),
        now()
      );
    END IF;
    
    RETURN NEW;
  END IF;
  
  RETURN NULL;
END;
$$;

-- Update the trigger function for assignment changes to properly capture user info
CREATE OR REPLACE FUNCTION trigger_log_assignment_changes()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  current_user_id uuid;
  current_user_name text;
  worker_name text;
BEGIN
  -- Get the current user ID
  current_user_id := auth.uid();
  
  -- Get the current user name
  SELECT name INTO current_user_name FROM workers WHERE id = current_user_id;
  
  IF TG_OP = 'INSERT' THEN
    -- Get the assigned worker name
    SELECT name INTO worker_name FROM workers WHERE id = NEW.worker_id;
    
    INSERT INTO task_history (
      task_id,
      user_id,
      action_type,
      old_value,
      new_value,
      description,
      created_at
    ) VALUES (
      NEW.task_id,
      current_user_id,
      'assignment_added'::task_action_type,
      NULL,
      worker_name,
      'Trabajador "' || COALESCE(worker_name, 'Desconocido') || '" asignado por ' || COALESCE(current_user_name, 'Usuario'),
      now()
    );
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    -- Get the unassigned worker name
    SELECT name INTO worker_name FROM workers WHERE id = OLD.worker_id;
    
    INSERT INTO task_history (
      task_id,
      user_id,
      action_type,
      old_value,
      new_value,
      description,
      created_at
    ) VALUES (
      OLD.task_id,
      current_user_id,
      'assignment_removed'::task_action_type,
      worker_name,
      NULL,
      'Trabajador "' || COALESCE(worker_name, 'Desconocido') || '" desasignado por ' || COALESCE(current_user_name, 'Usuario'),
      now()
    );
    RETURN OLD;
  END IF;
  
  RETURN NULL;
END;
$$;

-- Update the trigger function for attachment changes to properly capture user info
CREATE OR REPLACE FUNCTION trigger_log_attachment_changes()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  current_user_id uuid;
  current_user_name text;
BEGIN
  -- Get the current user ID
  current_user_id := auth.uid();
  
  -- Get the current user name
  SELECT name INTO current_user_name FROM workers WHERE id = current_user_id;
  
  IF TG_OP = 'INSERT' THEN
    INSERT INTO task_history (
      task_id,
      user_id,
      action_type,
      old_value,
      new_value,
      description,
      created_at
    ) VALUES (
      NEW.task_id,
      current_user_id,
      'attachment_added'::task_action_type,
      NULL,
      NEW.file_name,
      'Archivo "' || NEW.file_name || '" adjuntado por ' || COALESCE(current_user_name, 'Usuario'),
      now()
    );
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    INSERT INTO task_history (
      task_id,
      user_id,
      action_type,
      old_value,
      new_value,
      description,
      created_at
    ) VALUES (
      OLD.task_id,
      current_user_id,
      'attachment_removed'::task_action_type,
      OLD.file_name,
      NULL,
      'Archivo "' || OLD.file_name || '" eliminado por ' || COALESCE(current_user_name, 'Usuario'),
      now()
    );
    RETURN OLD;
  END IF;
  
  RETURN NULL;
END;
$$;

-- Update the trigger function for conversation changes to properly capture user info
CREATE OR REPLACE FUNCTION trigger_log_conversation_changes()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  current_user_name text;
BEGIN
  -- Get the user name directly from the conversation record
  SELECT name INTO current_user_name FROM workers WHERE id = NEW.user_id;
  
  INSERT INTO task_history (
    task_id,
    user_id,
    action_type,
    old_value,
    new_value,
    description,
    created_at
  ) VALUES (
    NEW.task_id,
    NEW.user_id,
    'comment_added'::task_action_type,
    NULL,
    LEFT(NEW.message, 50) || CASE WHEN LENGTH(NEW.message) > 50 THEN '...' ELSE '' END,
    'Comentario añadido por ' || COALESCE(current_user_name, 'Usuario'),
    now()
  );
  
  RETURN NEW;
END;
$$;

-- Recreate the triggers to use the updated functions
DROP TRIGGER IF EXISTS task_changes_trigger ON tasks;
CREATE TRIGGER task_changes_trigger
  AFTER INSERT OR UPDATE ON tasks
  FOR EACH ROW
  EXECUTE FUNCTION trigger_log_task_changes();

DROP TRIGGER IF EXISTS assignment_changes_trigger ON task_assignments;
CREATE TRIGGER assignment_changes_trigger
  AFTER INSERT OR DELETE ON task_assignments
  FOR EACH ROW
  EXECUTE FUNCTION trigger_log_assignment_changes();

DROP TRIGGER IF EXISTS attachment_changes_trigger ON task_attachments;
CREATE TRIGGER attachment_changes_trigger
  AFTER INSERT OR DELETE ON task_attachments
  FOR EACH ROW
  EXECUTE FUNCTION trigger_log_attachment_changes();

DROP TRIGGER IF EXISTS conversation_changes_trigger ON task_conversations;
CREATE TRIGGER conversation_changes_trigger
  AFTER INSERT ON task_conversations
  FOR EACH ROW
  EXECUTE FUNCTION trigger_log_conversation_changes();