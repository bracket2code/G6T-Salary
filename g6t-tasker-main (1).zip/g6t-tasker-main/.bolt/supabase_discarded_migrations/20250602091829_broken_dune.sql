/*
  # Update locations table with new values

  1. Changes
    - Safely update locations while preserving referential integrity
    - Set location_id to NULL for tasks referencing deleted locations
    - Insert new specified locations
  
  2. Security
    - Maintains existing RLS policies
    - Preserves data integrity with foreign key constraints
*/

-- First, set location_id to NULL for tasks that reference locations we'll delete
UPDATE tasks 
SET location_id = NULL 
WHERE location_id IN (
  SELECT id FROM locations 
  WHERE name NOT IN (
    'Mombassa', 'Teteria', 'La Virgen', 'FOMO', 'Dunna Playa', 
    'Balneario', 'LimaLimon', 'Oficina', 'Mandanga', 
    'Trastevere', 'Favorita', 'Ruina'
  )
);

-- Now we can safely delete locations that aren't in our new list
DELETE FROM locations 
WHERE name NOT IN (
  'Mombassa', 'Teteria', 'La Virgen', 'FOMO', 'Dunna Playa', 
  'Balneario', 'LimaLimon', 'Oficina', 'Mandanga', 
  'Trastevere', 'Favorita', 'Ruina'
);

-- Insert new locations if they don't exist
INSERT INTO locations (name)
SELECT unnest(ARRAY[
  'Mombassa', 'Teteria', 'La Virgen', 'FOMO', 'Dunna Playa',
  'Balneario', 'LimaLimon', 'Oficina', 'Mandanga',
  'Trastevere', 'Favorita', 'Ruina'
])
WHERE NOT EXISTS (
  SELECT 1 FROM locations 
  WHERE name = unnest
);