/*
  # Arreglar sistema completo de archivos y conversaciones

  1. Arreglar bucket de storage
    - Recrear bucket con configuración correcta
    - Arreglar políticas de storage

  2. Arreglar políticas RLS
    - Simplificar políticas de task_conversations
    - Simplificar políticas de conversation_attachments
    - Simplificar políticas de task_attachments

  3. Asegurar que todo funcione
    - Verificar que los usuarios puedan subir archivos
    - Verificar que los usuarios puedan escribir conversaciones
    - Verificar que los usuarios puedan ver y descargar archivos
*/

-- 1. ARREGLAR STORAGE BUCKET
-- Eliminar bucket existente si existe
DELETE FROM storage.buckets WHERE id = 'task-attachments';

-- Crear bucket nuevo con configuración correcta
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'task-attachments',
  'task-attachments',
  true, -- Público para facilitar acceso
  104857600, -- 100MB limit
  ARRAY[
    'image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml',
    'video/mp4', 'video/webm', 'video/quicktime', 'video/avi',
    'audio/webm', 'audio/mp3', 'audio/wav', 'audio/ogg', 'audio/mpeg',
    'application/pdf', 'text/plain', 'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
  ]
);

-- 2. ELIMINAR TODAS LAS POLÍTICAS DE STORAGE EXISTENTES
DROP POLICY IF EXISTS "Authenticated users can upload files" ON storage.objects;
DROP POLICY IF EXISTS "Public read access for task attachments" ON storage.objects;
DROP POLICY IF EXISTS "Users can delete own files" ON storage.objects;
DROP POLICY IF EXISTS "Users can update own files" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can upload task attachments" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can view task attachments" ON storage.objects;
DROP POLICY IF EXISTS "Users can delete their own task attachments" ON storage.objects;

-- 3. CREAR POLÍTICAS DE STORAGE SIMPLES Y FUNCIONALES
-- Permitir a usuarios autenticados subir archivos
CREATE POLICY "Allow authenticated uploads"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'task-attachments');

-- Permitir acceso público de lectura
CREATE POLICY "Allow public downloads"
ON storage.objects FOR SELECT TO public
USING (bucket_id = 'task-attachments');

-- Permitir a usuarios autenticados eliminar cualquier archivo
CREATE POLICY "Allow authenticated deletes"
ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'task-attachments');

-- Permitir a usuarios autenticados actualizar cualquier archivo
CREATE POLICY "Allow authenticated updates"
ON storage.objects FOR UPDATE TO authenticated
USING (bucket_id = 'task-attachments');

-- 4. ARREGLAR POLÍTICAS RLS DE TASK_CONVERSATIONS
-- Eliminar políticas existentes
DROP POLICY IF EXISTS "Authenticated users can view all conversations" ON task_conversations;
DROP POLICY IF EXISTS "Users can insert their own conversations" ON task_conversations;
DROP POLICY IF EXISTS "Users can update their own conversations" ON task_conversations;
DROP POLICY IF EXISTS "Users can delete their own conversations" ON task_conversations;
DROP POLICY IF EXISTS "Authenticated users can insert conversations" ON task_conversations;
DROP POLICY IF EXISTS "Workers can insert their own conversations" ON task_conversations;
DROP POLICY IF EXISTS "Workers can delete their own conversations" ON task_conversations;
DROP POLICY IF EXISTS "Workers can update their own conversations" ON task_conversations;

-- Crear políticas simples que funcionen
CREATE POLICY "Allow all conversation operations"
ON task_conversations FOR ALL TO authenticated
USING (true) WITH CHECK (true);

-- 5. ARREGLAR POLÍTICAS RLS DE CONVERSATION_ATTACHMENTS
-- Eliminar políticas existentes
DROP POLICY IF EXISTS "Authenticated users can view conversation attachments" ON conversation_attachments;
DROP POLICY IF EXISTS "Authenticated users can insert conversation attachments" ON conversation_attachments;
DROP POLICY IF EXISTS "Users can delete attachments from their own conversations" ON conversation_attachments;

-- Crear políticas simples que funcionen
CREATE POLICY "Allow all conversation attachment operations"
ON conversation_attachments FOR ALL TO authenticated
USING (true) WITH CHECK (true);

-- 6. ARREGLAR POLÍTICAS RLS DE TASK_ATTACHMENTS
-- Eliminar políticas existentes
DROP POLICY IF EXISTS "Authenticated users can view all attachments" ON task_attachments;
DROP POLICY IF EXISTS "Authenticated users can insert attachments" ON task_attachments;
DROP POLICY IF EXISTS "Users can delete their own attachments" ON task_attachments;

-- Crear políticas simples que funcionen
CREATE POLICY "Allow all task attachment operations"
ON task_attachments FOR ALL TO authenticated
USING (true) WITH CHECK (true);

-- 7. ASEGURAR QUE RLS ESTÉ HABILITADO
ALTER TABLE task_conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversation_attachments ENABLE ROW LEVEL SECURITY;
ALTER TABLE task_attachments ENABLE ROW LEVEL SECURITY;

-- 8. CREAR FUNCIÓN PARA VERIFICAR CONFIGURACIÓN
CREATE OR REPLACE FUNCTION verify_storage_setup()
RETURNS TABLE (
  component text,
  status text,
  details text
) AS $$
BEGIN
  -- Verificar bucket
  RETURN QUERY
  SELECT 
    'Storage Bucket'::text,
    CASE WHEN EXISTS (SELECT 1 FROM storage.buckets WHERE id = 'task-attachments') 
         THEN 'OK' ELSE 'ERROR' END::text,
    'Bucket task-attachments'::text;
  
  -- Verificar políticas de storage
  RETURN QUERY
  SELECT 
    'Storage Policies'::text,
    CASE WHEN EXISTS (
      SELECT 1 FROM pg_policies 
      WHERE schemaname = 'storage' 
      AND tablename = 'objects' 
      AND policyname = 'Allow authenticated uploads'
    ) THEN 'OK' ELSE 'ERROR' END::text,
    'Storage policies configured'::text;
  
  -- Verificar políticas de conversaciones
  RETURN QUERY
  SELECT 
    'Conversation Policies'::text,
    CASE WHEN EXISTS (
      SELECT 1 FROM pg_policies 
      WHERE schemaname = 'public' 
      AND tablename = 'task_conversations' 
      AND policyname = 'Allow all conversation operations'
    ) THEN 'OK' ELSE 'ERROR' END::text,
    'Conversation policies configured'::text;
    
END;
$$ LANGUAGE plpgsql;