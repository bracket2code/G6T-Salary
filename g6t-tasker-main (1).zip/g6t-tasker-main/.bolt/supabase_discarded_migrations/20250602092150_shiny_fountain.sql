/*
  # Delete all tasks

  1. Changes
    - Delete all existing tasks from the tasks table
  
  2. Security
    - No security changes needed
    - Existing RLS policies remain in place
*/

-- Delete all tasks
DELETE FROM tasks;