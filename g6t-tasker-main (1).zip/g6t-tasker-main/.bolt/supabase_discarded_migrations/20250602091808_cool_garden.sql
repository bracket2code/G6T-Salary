/*
  # Update locations table with new values

  1. Changes
    - Delete existing locations
    - Insert new locations:
      - Mombassa
      - Teteria
      - La Virgen
      - FOMO
      - Dunna Playa
      - Balneario
      - LimaLimon
      - Oficina
      - Mandanga
      - Trastevere
      - Favorita
      - Ruina
*/

-- Delete all existing locations
DELETE FROM locations;

-- Insert new locations
INSERT INTO locations (name) VALUES
  ('Mombassa'),
  ('Teteria'),
  ('La Virgen'),
  ('FOMO'),
  ('Dunna Playa'),
  ('Balneario'),
  ('LimaLimon'),
  ('Oficina'),
  ('Mandanga'),
  ('Trastevere'),
  ('Favorita'),
  ('Ruina');