/*
  # Insert locations in alphabetical order
  
  This migration adds a set of predefined locations to the database in alphabetical order.
  
  1. Changes
    - Inserts 12 locations in alphabetical order
*/

INSERT INTO locations (name) VALUES
  ('Balneario'),
  ('Dunna Playa'),
  ('Favorita'),
  ('FOMO'),
  ('La Virgen'),
  ('LimaLimon'),
  ('Mandanga'),
  ('Mombassa'),
  ('Oficina'),
  ('Ruina'),
  ('Teteria'),
  ('Trastevere');