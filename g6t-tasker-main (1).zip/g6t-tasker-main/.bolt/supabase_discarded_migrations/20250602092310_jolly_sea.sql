/*
  # Create locations

  1. Changes
    - Insert new locations in alphabetical order
  
  2. Data
    - Insert 12 predefined locations
*/

-- Insert locations in alphabetical order
INSERT INTO locations (name)
VALUES
  ('Balneario'),
  ('Dunna Playa'),
  ('Favorita'),
  ('FOMO'),
  ('La Virgen'),
  ('LimaLimon'),
  ('Mandanga'),
  ('Mombassa'),
  ('Oficina'),
  ('Ruina'),
  ('Teteria'),
  ('Trastevere');