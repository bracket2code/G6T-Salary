/*
  # Add sample maintenance tasks

  1. Changes
    - Insert sample tasks with different priorities, statuses, and areas
    - Tasks include realistic maintenance scenarios
    - Varied due dates for calendar testing
  
  2. Data
    - Tasks cover different types of maintenance:
      - Preventive
      - Corrective
      - Predictive
    - Different areas:
      - Mechanical
      - Electrical
      - Plumbing
      - HVAC
      - General
*/

-- Insert sample tasks
INSERT INTO tasks (
  title,
  description,
  status,
  priority,
  type,
  area,
  due_date,
  created_at
) VALUES
  (
    'Inspección de Sistema HVAC',
    'Realizar inspección trimestral del sistema de climatización incluyendo filtros, conductos y unidades de tratamiento de aire.',
    'pending',
    'medium',
    'preventive',
    'hvac',
    (CURRENT_DATE + INTERVAL '2 days'),
    CURRENT_TIMESTAMP
  ),
  (
    'Reparación Urgente de Fuga de Agua',
    'Se ha detectado una fuga importante en la tubería principal del segundo piso. Requiere atención inmediata.',
    'in_progress',
    'critical',
    'corrective',
    'plumbing',
    (CURRENT_DATE + INTERVAL '1 day'),
    CURRENT_TIMESTAMP
  ),
  (
    'Mantenimiento de Generador Eléctrico',
    'Realizar mantenimiento preventivo del generador de emergencia, incluye cambio de aceite y filtros.',
    'pending',
    'high',
    'preventive',
    'electrical',
    (CURRENT_DATE + INTERVAL '5 days'),
    CURRENT_TIMESTAMP
  ),
  (
    'Calibración de Equipos de Medición',
    'Calibrar instrumentos de medición y sensores de presión en la sala de máquinas.',
    'completed',
    'medium',
    'predictive',
    'mechanical',
    (CURRENT_DATE - INTERVAL '1 day'),
    CURRENT_TIMESTAMP
  ),
  (
    'Limpieza de Canaletas',
    'Limpieza y mantenimiento de canaletas y bajantes en todo el edificio.',
    'pending',
    'low',
    'preventive',
    'general',
    (CURRENT_DATE + INTERVAL '7 days'),
    CURRENT_TIMESTAMP
  ),
  (
    'Reparación de Motor de Ventilación',
    'El motor del sistema de ventilación presenta ruidos anormales. Requiere revisión y posible reemplazo.',
    'in_progress',
    'high',
    'corrective',
    'mechanical',
    (CURRENT_DATE + INTERVAL '3 days'),
    CURRENT_TIMESTAMP
  ),
  (
    'Inspección de Paneles Eléctricos',
    'Realizar termografía de paneles eléctricos principales para detectar puntos calientes.',
    'pending',
    'medium',
    'predictive',
    'electrical',
    (CURRENT_DATE + INTERVAL '10 days'),
    CURRENT_TIMESTAMP
  ),
  (
    'Mantenimiento de Bombas de Agua',
    'Mantenimiento preventivo del sistema de bombeo, incluye revisión de sellos y rodamientos.',
    'pending',
    'medium',
    'preventive',
    'mechanical',
    (CURRENT_DATE + INTERVAL '4 days'),
    CURRENT_TIMESTAMP
  ),
  (
    'Reparación de Aire Acondicionado',
    'Unidad de A/C en oficina principal no enfría. Posible fuga de refrigerante.',
    'in_progress',
    'high',
    'corrective',
    'hvac',
    (CURRENT_DATE + INTERVAL '1 day'),
    CURRENT_TIMESTAMP
  ),
  (
    'Actualización de Iluminación LED',
    'Reemplazar luminarias antiguas por nuevas LED en áreas comunes para mejorar eficiencia.',
    'pending',
    'low',
    'preventive',
    'electrical',
    (CURRENT_DATE + INTERVAL '15 days'),
    CURRENT_TIMESTAMP
  );