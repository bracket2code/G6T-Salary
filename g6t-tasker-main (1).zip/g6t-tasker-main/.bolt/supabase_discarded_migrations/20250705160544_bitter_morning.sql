/*
  # Verificar y corregir tabla de archivos adjuntos

  1. Verificaciones
    - Estructura de la tabla task_attachments
    - Políticas RLS
    - Triggers existentes

  2. Correcciones
    - Asegurar que todos los campos estén presentes
    - Verificar tipos de datos correctos
*/

-- Verificar estructura actual de la tabla
DO $$
BEGIN
  -- Verificar si la tabla existe y mostrar su estructura
  IF EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'task_attachments') THEN
    RAISE NOTICE 'Tabla task_attachments existe';
    
    -- Mostrar columnas
    FOR rec IN 
      SELECT column_name, data_type, is_nullable, column_default
      FROM information_schema.columns 
      WHERE table_name = 'task_attachments' 
      ORDER BY ordinal_position
    LOOP
      RAISE NOTICE 'Columna: % | Tipo: % | Nullable: % | Default: %', 
        rec.column_name, rec.data_type, rec.is_nullable, rec.column_default;
    END LOOP;
  ELSE
    RAISE NOTICE 'Tabla task_attachments NO existe';
  END IF;
END $$;

-- Asegurar que la tabla tenga la estructura correcta
CREATE TABLE IF NOT EXISTS task_attachments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  file_name text NOT NULL,
  file_type text NOT NULL CHECK (file_type IN ('audio', 'video', 'image')),
  file_url text NOT NULL,
  file_size bigint,
  duration integer,
  uploaded_by uuid REFERENCES workers(id),
  created_at timestamptz DEFAULT now()
);

-- Verificar y crear índices si no existen
CREATE INDEX IF NOT EXISTS idx_task_attachments_task_id ON task_attachments(task_id);
CREATE INDEX IF NOT EXISTS idx_task_attachments_file_type ON task_attachments(file_type);
CREATE INDEX IF NOT EXISTS idx_task_attachments_uploaded_by ON task_attachments(uploaded_by);

-- Habilitar RLS
ALTER TABLE task_attachments ENABLE ROW LEVEL SECURITY;

-- Crear políticas RLS si no existen
DO $$
BEGIN
  -- Política para SELECT
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'task_attachments' 
    AND policyname = 'Allow all task attachment operations'
  ) THEN
    CREATE POLICY "Allow all task attachment operations"
      ON task_attachments
      FOR ALL
      TO authenticated
      USING (true)
      WITH CHECK (true);
  END IF;
END $$;

-- Verificar datos existentes
DO $$
DECLARE
  attachment_count integer;
  sample_record record;
BEGIN
  SELECT COUNT(*) INTO attachment_count FROM task_attachments;
  RAISE NOTICE 'Total de archivos adjuntos en la tabla: %', attachment_count;
  
  IF attachment_count > 0 THEN
    -- Mostrar un registro de ejemplo
    SELECT * INTO sample_record FROM task_attachments LIMIT 1;
    RAISE NOTICE 'Ejemplo de registro: ID=%, task_id=%, file_name=%, file_type=%, file_url=%, file_size=%, created_at=%', 
      sample_record.id, sample_record.task_id, sample_record.file_name, 
      sample_record.file_type, sample_record.file_url, sample_record.file_size, sample_record.created_at;
  END IF;
END $$;