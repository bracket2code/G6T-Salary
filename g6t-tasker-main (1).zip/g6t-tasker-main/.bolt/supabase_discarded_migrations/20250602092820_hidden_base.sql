/*
  # Insert locations in alphabetical order
  
  1. New Data
    - Inserts 12 locations in alphabetical order
*/

INSERT INTO locations (name) VALUES
  ('Balneario'),
  ('Dunna Playa'),
  ('Favorita'),
  ('FOMO'),
  ('La Virgen'),
  ('LimaLimon'),
  ('Mandanga'),
  ('Mombassa'),
  ('Oficina'),
  ('Ruina'),
  ('Teteria'),
  ('Trastevere');