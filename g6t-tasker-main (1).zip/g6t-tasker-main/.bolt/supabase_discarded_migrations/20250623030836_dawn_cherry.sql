/*
  # Fix task status filters with new states

  1. Database Updates
    - Ensure get_task_statuses function exists and works
    - Update task status enum with all new states
    - Fix any remaining references to old status values

  2. Status Updates
    - Sin Asignar: Tasks without workers assigned
    - Pendiente: Tasks assigned but not started
    - En Proceso: Tasks currently being worked on
    - Aplazada: Tasks postponed temporarily
    - Cancelada: Tasks cancelled permanently
    - Completada: Tasks finished successfully
    - Archivada: Tasks archived for reference
*/

-- Ensure the task status enum has all the correct values
DO $$
BEGIN
  -- Check if the enum already has the new values
  IF NOT EXISTS (
    SELECT 1 FROM pg_enum 
    WHERE enumlabel = 'sin_asignar' 
    AND enumtypid = (SELECT oid FROM pg_type WHERE typname = 'task_status')
  ) THEN
    -- If not, we need to recreate the enum properly
    
    -- First, create a temporary enum with all the new values
    CREATE TYPE task_status_temp AS ENUM (
      'sin_asignar', 
      'pendiente', 
      'en_proceso', 
      'aplazada', 
      'cancelada', 
      'completada', 
      'archivada'
    );
    
    -- Add temporary column
    ALTER TABLE tasks ADD COLUMN status_temp task_status_temp;
    
    -- Migrate data
    UPDATE tasks SET status_temp = CASE 
      WHEN status::text = 'pendiente' THEN 'pendiente'::task_status_temp
      WHEN status::text = 'en_progreso' THEN 'en_proceso'::task_status_temp
      WHEN status::text = 'en_proceso' THEN 'en_proceso'::task_status_temp
      WHEN status::text = 'completada' THEN 'completada'::task_status_temp
      WHEN status::text = 'cancelada' THEN 'cancelada'::task_status_temp
      ELSE 'sin_asignar'::task_status_temp
    END;
    
    -- Drop old column and enum
    ALTER TABLE tasks DROP COLUMN status;
    DROP TYPE IF EXISTS task_status;
    
    -- Rename temp enum and column
    ALTER TYPE task_status_temp RENAME TO task_status;
    ALTER TABLE tasks RENAME COLUMN status_temp TO status;
    
    -- Set default and not null
    ALTER TABLE tasks ALTER COLUMN status SET NOT NULL;
    ALTER TABLE tasks ALTER COLUMN status SET DEFAULT 'sin_asignar'::task_status;
  END IF;
END $$;

-- Create or replace the function to get task statuses
CREATE OR REPLACE FUNCTION get_task_statuses()
RETURNS TABLE (value text, label text)
LANGUAGE sql
SECURITY DEFINER
STABLE
AS $$
  SELECT 
    unnest(ARRAY[
      'sin_asignar', 
      'pendiente', 
      'en_proceso', 
      'aplazada', 
      'cancelada', 
      'completada', 
      'archivada'
    ]) as value,
    unnest(ARRAY[
      'Sin Asignar', 
      'Pendiente', 
      'En Proceso', 
      'Aplazada', 
      'Cancelada', 
      'Completada', 
      'Archivada'
    ]) as label;
$$;

-- Update existing tasks to use sin_asignar for unassigned tasks
UPDATE tasks 
SET status = 'sin_asignar'
WHERE id NOT IN (
  SELECT DISTINCT task_id FROM task_assignments
) AND status NOT IN ('completada', 'cancelada', 'archivada');

-- Ensure the trigger function exists and works correctly
CREATE OR REPLACE FUNCTION update_task_status_on_assignment_change()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- When an assignment is deleted, check if task becomes unassigned
  IF TG_OP = 'DELETE' THEN
    -- Check if the task has no more assignments
    IF NOT EXISTS (
      SELECT 1 FROM task_assignments 
      WHERE task_id = OLD.task_id
    ) THEN
      -- Change status to sin_asignar only if not in final states
      UPDATE tasks 
      SET status = 'sin_asignar'
      WHERE id = OLD.task_id 
        AND status NOT IN ('completada', 'cancelada', 'archivada');
    END IF;
    RETURN OLD;
  END IF;
  
  -- When an assignment is added, change from sin_asignar to pendiente
  IF TG_OP = 'INSERT' THEN
    UPDATE tasks 
    SET status = 'pendiente'
    WHERE id = NEW.task_id 
      AND status = 'sin_asignar';
    RETURN NEW;
  END IF;
  
  RETURN NULL;
END $$;

-- Ensure the trigger exists
DROP TRIGGER IF EXISTS trigger_update_task_status_on_assignment ON task_assignments;
CREATE TRIGGER trigger_update_task_status_on_assignment
  AFTER INSERT OR DELETE ON task_assignments
  FOR EACH ROW
  EXECUTE FUNCTION update_task_status_on_assignment_change();

-- Test the function to make sure it works
DO $$
DECLARE
  test_result RECORD;
BEGIN
  -- Test the get_task_statuses function
  SELECT * FROM get_task_statuses() LIMIT 1 INTO test_result;
  
  IF test_result IS NULL THEN
    RAISE EXCEPTION 'get_task_statuses function is not working correctly';
  ELSE
    RAISE NOTICE 'get_task_statuses function is working. First result: % = %', test_result.value, test_result.label;
  END IF;
END $$;