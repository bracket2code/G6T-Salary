/*
  # Delete pending tasks
  
  1. Changes
    - Delete all tasks with status 'pending'
*/

DELETE FROM tasks WHERE status = 'pending';