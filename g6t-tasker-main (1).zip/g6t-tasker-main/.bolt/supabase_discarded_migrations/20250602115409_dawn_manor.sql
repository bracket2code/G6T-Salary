/*
  # Add status and priority enums

  1. Changes
    - Create task_status enum type
    - Create task_priority enum type
    - Create functions to get all statuses and priorities
*/

-- Create enum types if they don't exist
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'task_status') THEN
    CREATE TYPE task_status AS ENUM ('pendiente', 'en_progreso', 'completada', 'cancelada');
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'task_priority') THEN
    CREATE TYPE task_priority AS ENUM ('baja', 'media', 'alta', 'critica');
  END IF;
END $$;

-- Function to get all task statuses
CREATE OR REPLACE FUNCTION get_task_statuses()
RETURNS TABLE (value text, label text)
LANGUAGE sql
STABLE
AS $$
  SELECT 
    unnest(enum_range(NULL::task_status))::text as value,
    CASE 
      WHEN unnest(enum_range(NULL::task_status))::text = 'pendiente' THEN 'Pendiente'
      WHEN unnest(enum_range(NULL::task_status))::text = 'en_progreso' THEN 'En Progreso'
      WHEN unnest(enum_range(NULL::task_status))::text = 'completada' THEN 'Completada'
      WHEN unnest(enum_range(NULL::task_status))::text = 'cancelada' THEN 'Cancelada'
    END as label;
$$;

-- Function to get all task priorities
CREATE OR REPLACE FUNCTION get_task_priorities()
RETURNS TABLE (value text, label text)
LANGUAGE sql
STABLE
AS $$
  SELECT 
    unnest(enum_range(NULL::task_priority))::text as value,
    CASE 
      WHEN unnest(enum_range(NULL::task_priority))::text = 'baja' THEN 'Baja'
      WHEN unnest(enum_range(NULL::task_priority))::text = 'media' THEN 'Media'
      WHEN unnest(enum_range(NULL::task_priority))::text = 'alta' THEN 'Alta'
      WHEN unnest(enum_range(NULL::task_priority))::text = 'critica' THEN 'Crítica'
    END as label;
$$;