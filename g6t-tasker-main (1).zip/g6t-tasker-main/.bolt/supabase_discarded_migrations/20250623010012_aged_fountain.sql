/*
  # Fix task attachments and assignments issues

  1. Schema Changes
    - Modify task_attachments.task_id column to accept TEXT instead of UUID to support temporary IDs
    - This allows storing temporary string IDs during task creation

  2. Security Updates
    - Update RLS policies for task_assignments table to allow proper CRUD operations
    - Ensure authenticated users can manage task assignments appropriately

  3. Data Integrity
    - Maintain foreign key relationships where possible
    - Ensure existing data remains intact
*/

-- First, modify the task_attachments table to support temporary task IDs
ALTER TABLE task_attachments DROP CONSTRAINT IF EXISTS task_attachments_task_id_fkey;

-- Change task_id column from UUID to TEXT to support temporary IDs
ALTER TABLE task_attachments ALTER COLUMN task_id TYPE TEXT;

-- Update RLS policies for task_assignments table
DROP POLICY IF EXISTS "Usuarios pueden crear asignaciones" ON task_assignments;
DROP POLICY IF EXISTS "Usuarios pueden eliminar asignaciones" ON task_assignments;
DROP POLICY IF EXISTS "Usuarios pueden ver todas las asignaciones" ON task_assignments;

-- Create more permissive RLS policies for task_assignments
CREATE POLICY "Authenticated users can insert task assignments"
  ON task_assignments
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can view task assignments"
  ON task_assignments
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can delete task assignments"
  ON task_assignments
  FOR DELETE
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can update task assignments"
  ON task_assignments
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Add a new foreign key constraint that only applies to UUID values
-- This allows temporary string IDs while maintaining referential integrity for real UUIDs
ALTER TABLE task_attachments 
ADD CONSTRAINT task_attachments_task_id_fkey 
FOREIGN KEY (task_id) 
REFERENCES tasks(id) 
ON DELETE CASCADE
NOT VALID;

-- Create a function to validate task_id format
CREATE OR REPLACE FUNCTION validate_task_id()
RETURNS TRIGGER AS $$
BEGIN
  -- Allow temporary IDs (starting with 'temp_') or valid UUIDs
  IF NEW.task_id ~ '^temp_' OR NEW.task_id ~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' THEN
    RETURN NEW;
  ELSE
    RAISE EXCEPTION 'Invalid task_id format: %', NEW.task_id;
  END IF;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to validate task_id format on insert/update
DROP TRIGGER IF EXISTS validate_task_id_trigger ON task_attachments;
CREATE TRIGGER validate_task_id_trigger
  BEFORE INSERT OR UPDATE ON task_attachments
  FOR EACH ROW
  EXECUTE FUNCTION validate_task_id();