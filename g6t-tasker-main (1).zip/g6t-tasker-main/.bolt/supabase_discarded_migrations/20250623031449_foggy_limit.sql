/*
  # Fix task status enum to match application requirements

  1. Changes
    - Add missing status values to task_status enum: 'sin_asignar', 'en_proceso', 'aplazada', 'archivada'
    - Rename 'en_progreso' to 'en_proceso' for consistency
    - Update any existing tasks that use the old status values

  2. Security
    - No changes to RLS policies needed
*/

-- First, add the new enum values
ALTER TYPE task_status ADD VALUE IF NOT EXISTS 'sin_asignar';
ALTER TYPE task_status ADD VALUE IF NOT EXISTS 'en_proceso';
ALTER TYPE task_status ADD VALUE IF NOT EXISTS 'aplazada';
ALTER TYPE task_status ADD VALUE IF NOT EXISTS 'archivada';

-- Update any existing tasks that might have 'en_progreso' to use 'en_proceso'
UPDATE tasks SET status = 'en_proceso' WHERE status = 'en_progreso';

-- Note: We cannot remove 'en_progreso' from the enum directly in PostgreSQL
-- But we've added all the required values and updated existing data