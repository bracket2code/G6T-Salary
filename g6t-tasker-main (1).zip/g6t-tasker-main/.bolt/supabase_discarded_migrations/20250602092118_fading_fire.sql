/*
  # Clean tasks and update locations
  
  1. Changes
    - Delete all existing tasks
    - Update locations table with new values in alphabetical order
  
  2. Operations
    - First delete all tasks to avoid foreign key constraints
    - Then delete and recreate locations in alphabetical order
*/

-- First, delete all tasks
DELETE FROM tasks;

-- Now we can safely delete all locations
DELETE FROM locations;

-- Insert new locations in alphabetical order
INSERT INTO locations (name)
VALUES
  ('Balneario'),
  ('Dunna Playa'),
  ('Favorita'),
  ('FOMO'),
  ('La Virgen'),
  ('LimaLimon'),
  ('Mandanga'),
  ('Mombassa'),
  ('Oficina'),
  ('Ruina'),
  ('Teteria'),
  ('Trastevere');