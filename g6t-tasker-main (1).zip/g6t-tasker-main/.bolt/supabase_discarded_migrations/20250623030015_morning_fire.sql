/*
  # Update task status enum values

  1. Changes
     - Update task_status enum from ['pendiente', 'en_progreso', 'completada', 'cancelada'] 
       to ['sin_asignar', 'pendiente', 'completada', 'aplazada']
     - Migrate existing data appropriately
     - Update all dependent functions
     - Add automatic status management based on task assignments

  2. Security
     - Maintain existing RLS policies
     - Update functions with proper security definer
*/

-- Step 1: Drop all dependent functions first
DROP FUNCTION IF EXISTS get_tasks_with_assignments() CASCADE;
DROP FUNCTION IF EXISTS get_tasks_with_attachments() CASCADE;
DROP FUNCTION IF EXISTS get_tasks_with_recurrence() CASCADE;

-- Step 2: Create new enum type
CREATE TYPE task_status_new AS ENUM ('sin_asignar', 'pendiente', 'completada', 'aplazada');

-- Step 3: Add new column with new enum type
ALTER TABLE tasks ADD COLUMN status_new task_status_new;

-- Step 4: Migrate existing data
UPDATE tasks SET status_new = CASE 
  WHEN status = 'pendiente' THEN 'pendiente'::task_status_new
  WHEN status = 'en_progreso' THEN 'pendiente'::task_status_new
  WHEN status = 'completada' THEN 'completada'::task_status_new
  WHEN status = 'cancelada' THEN 'aplazada'::task_status_new
  ELSE 'pendiente'::task_status_new
END;

-- Step 5: Make new column not null
ALTER TABLE tasks ALTER COLUMN status_new SET NOT NULL;

-- Step 6: Drop old column
ALTER TABLE tasks DROP COLUMN status;

-- Step 7: Rename new column to original name
ALTER TABLE tasks RENAME COLUMN status_new TO status;

-- Step 8: Set default value (using the new enum type name)
ALTER TABLE tasks ALTER COLUMN status SET DEFAULT 'pendiente'::task_status_new;

-- Step 9: Drop old enum type (now safe since functions are dropped)
DROP TYPE task_status;

-- Step 10: Rename new enum type
ALTER TYPE task_status_new RENAME TO task_status;

-- Step 11: Fix the default value to use the correct enum name
ALTER TABLE tasks ALTER COLUMN status SET DEFAULT 'pendiente'::task_status;

-- Step 12: Update function for getting task statuses
CREATE OR REPLACE FUNCTION get_task_statuses()
RETURNS TABLE (value text, label text)
LANGUAGE sql
SECURITY DEFINER
AS $$
  SELECT 
    unnest(ARRAY['sin_asignar', 'pendiente', 'completada', 'aplazada']) as value,
    unnest(ARRAY['Sin Asignar', 'Pendiente', 'Completada', 'Aplazada']) as label;
$$;

-- Step 13: Create function to automatically update task status based on assignments
CREATE OR REPLACE FUNCTION update_task_status_on_assignment_change()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- When an assignment is deleted, check if task becomes unassigned
  IF TG_OP = 'DELETE' THEN
    -- Check if the task has no more assignments
    IF NOT EXISTS (
      SELECT 1 FROM task_assignments 
      WHERE task_id = OLD.task_id
    ) THEN
      -- Change status to sin_asignar only if not completed
      UPDATE tasks 
      SET status = 'sin_asignar'
      WHERE id = OLD.task_id 
        AND status != 'completada';
    END IF;
    RETURN OLD;
  END IF;
  
  -- When an assignment is added, change from sin_asignar to pendiente
  IF TG_OP = 'INSERT' THEN
    UPDATE tasks 
    SET status = 'pendiente'
    WHERE id = NEW.task_id 
      AND status = 'sin_asignar';
    RETURN NEW;
  END IF;
  
  RETURN NULL;
END $$;

-- Step 14: Create trigger for automatic status updates
DROP TRIGGER IF EXISTS trigger_update_task_status_on_assignment ON task_assignments;
CREATE TRIGGER trigger_update_task_status_on_assignment
  AFTER INSERT OR DELETE ON task_assignments
  FOR EACH ROW
  EXECUTE FUNCTION update_task_status_on_assignment_change();

-- Step 15: Update existing tasks to set sin_asignar status where appropriate
UPDATE tasks 
SET status = 'sin_asignar'
WHERE id NOT IN (
  SELECT DISTINCT task_id FROM task_assignments
) AND status != 'completada';

-- Step 16: Recreate get_tasks_with_attachments function
CREATE OR REPLACE FUNCTION get_tasks_with_attachments()
RETURNS TABLE (
  task_id uuid,
  task_title text,
  task_description text,
  task_status task_status,
  task_priority task_priority,
  task_location_id uuid,
  task_location_name text,
  task_created_at timestamptz,
  task_updated_at timestamptz,
  task_start_date timestamptz,
  task_end_date timestamptz,
  assigned_workers json,
  attachments json
)
LANGUAGE sql
SECURITY DEFINER
AS $$
  SELECT 
    t.id as task_id,
    t.title as task_title,
    t.description as task_description,
    t.status as task_status,
    t.priority as task_priority,
    t.location_id as task_location_id,
    l.name as task_location_name,
    t.created_at as task_created_at,
    t.updated_at as task_updated_at,
    t.start_date as task_start_date,
    t.end_date as task_end_date,
    COALESCE(
      (
        SELECT json_agg(
          json_build_object(
            'id', w.id,
            'name', w.name,
            'email', w.email,
            'role', w.role
          )
        )
        FROM task_assignments ta
        JOIN workers w ON w.id = ta.worker_id
        WHERE ta.task_id = t.id
      ),
      '[]'::json
    ) as assigned_workers,
    COALESCE(
      (
        SELECT json_agg(
          json_build_object(
            'id', att.id,
            'fileName', att.file_name,
            'fileType', att.file_type,
            'fileUrl', att.file_url,
            'fileSize', att.file_size,
            'duration', att.duration,
            'uploadedBy', att.uploaded_by,
            'uploaderName', w_uploader.name,
            'createdAt', att.created_at
          )
        )
        FROM task_attachments att
        LEFT JOIN workers w_uploader ON w_uploader.id = att.uploaded_by
        WHERE att.task_id = t.id
        ORDER BY att.created_at DESC
      ),
      '[]'::json
    ) as attachments
  FROM tasks t
  LEFT JOIN locations l ON l.id = t.location_id
  ORDER BY t.created_at DESC;
$$;

-- Step 17: Recreate get_tasks_with_recurrence function
CREATE OR REPLACE FUNCTION get_tasks_with_recurrence()
RETURNS TABLE (
  task_id uuid,
  task_title text,
  task_description text,
  task_status task_status,
  task_priority task_priority,
  task_location_id uuid,
  task_location_name text,
  task_created_at timestamptz,
  task_updated_at timestamptz,
  task_start_date timestamptz,
  task_end_date timestamptz,
  assigned_workers json,
  attachments json,
  recurrence_config json
)
LANGUAGE sql
SECURITY DEFINER
AS $$
  SELECT 
    t.id as task_id,
    t.title as task_title,
    t.description as task_description,
    t.status as task_status,
    t.priority as task_priority,
    t.location_id as task_location_id,
    l.name as task_location_name,
    t.created_at as task_created_at,
    t.updated_at as task_updated_at,
    t.start_date as task_start_date,
    t.end_date as task_end_date,
    COALESCE(
      (
        SELECT json_agg(
          json_build_object(
            'id', w.id,
            'name', w.name,
            'email', w.email,
            'role', w.role
          )
        )
        FROM task_assignments ta
        JOIN workers w ON w.id = ta.worker_id
        WHERE ta.task_id = t.id
      ),
      '[]'::json
    ) as assigned_workers,
    COALESCE(
      (
        SELECT json_agg(
          json_build_object(
            'id', att.id,
            'fileName', att.file_name,
            'fileType', att.file_type,
            'fileUrl', att.file_url,
            'fileSize', att.file_size,
            'duration', att.duration,
            'uploadedBy', att.uploaded_by,
            'uploaderName', w_uploader.name,
            'createdAt', att.created_at
          )
        )
        FROM task_attachments att
        LEFT JOIN workers w_uploader ON w_uploader.id = att.uploaded_by
        WHERE att.task_id = t.id
        ORDER BY att.created_at DESC
      ),
      '[]'::json
    ) as attachments,
    COALESCE(
      (
        SELECT json_build_object(
          'id', tr.id,
          'recurrenceType', tr.recurrence_type,
          'intervalValue', tr.interval_value,
          'daysOfWeek', tr.days_of_week,
          'dayOfMonth', tr.day_of_month,
          'monthOfYear', tr.month_of_year,
          'startDate', tr.start_date,
          'endDate', tr.end_date,
          'status', tr.status
        )
        FROM task_recurrence tr
        WHERE tr.task_id = t.id
      ),
      null
    ) as recurrence_config
  FROM tasks t
  LEFT JOIN locations l ON l.id = t.location_id
  ORDER BY t.created_at DESC;
$$;